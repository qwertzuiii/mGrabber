## How to edit Source Code
1. Install Python (3.9.x)
2. Open CMD and type: "pip install skingrabber"

Now you can change the Source code.
