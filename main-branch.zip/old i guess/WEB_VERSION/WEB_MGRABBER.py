import os, json
import webbrowser

openWeb=False

class file:
    def getcontent(filename, byteVersion=False):
        if byteVersion:
            return open(filename, "rb").read()
        if byteVersion == False:
            return open(filename, "r").read()
        else:
            raise TypeError('Byte version argument must be boolean, not string or integer')

CONFIG = json.loads(open("config.json", 'r').read())
htmlbase = CONFIG['files']["html"]
sinbase = CONFIG['files']["single"]



from flask import Flask, render_template, request
app = Flask(__name__, template_folder='', static_folder='')


# Functions

@app.route('/')
def main_index():
    headerData = file.getcontent(sinbase[0] + sinbase[1])
    header_data = str.join("", headerData.splitlines())
    return render_template(htmlbase[0] + htmlbase[1], header=header_data)


if __name__ == '__main__':
    if openWeb:
        webbrowser.open_new_tab('http://127.0.0.1:5000/')
    app.run(debug=True)