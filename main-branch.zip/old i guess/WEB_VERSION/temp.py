import webbrowser

params = "scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,width=0,height=0,left=-1000,top=-1000"
wbrowser = webbrowser.get('windows-default')
print(wbrowser)

webbrowser.register('windows-default', instance=webbrowser.get('windows-default'), klass=params)

webbrowser.open('https://google.com/', 1, autoraise=True)