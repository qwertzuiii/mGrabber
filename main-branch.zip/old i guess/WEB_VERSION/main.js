// Functions
function getMeta(metaName) { // Get meta content
    const metas = document.getElementsByTagName('meta');
  
    for (let i = 0; i < metas.length; i++) {
        if (metas[i].getAttribute('name') === metaName) {
            return metas[i].getAttribute('content');
        }
    }
  
    return '';
}

function onLoadWebsite() {

    // Loading Header on begin
    headerData = getMeta('data_Header')
    const getHeaderDiv = document.getElementById('spawn?header');

    getHeaderDiv.innerHTML = headerData;
}


// End
window.onload = onLoadWebsite;